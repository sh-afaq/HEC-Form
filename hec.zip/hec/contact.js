function readVariable() {
    var str1 = document.getElementById("c-country").value;          
    var str2 = document.getElementById("c-city").value;
    var str3 = document.getElementById("c-district").value;
    var str4 = document.getElementById("address").value;
    var str5 = document.getElementById("postal").value;
    
    var str6 = document.getElementById("email").value;
    var str7 = document.getElementById("p-cellphone").value;
    
    //printing values
    
    document.getElementById('span1').textContent = str1;
    document.getElementById('span2').textContent = str2;
    document.getElementById('span3').textContent =str3;
    document.getElementById('span4').textContent = str4;
    document.getElementById('span5').textContent =str5;
    document.getElementById('span6').textContent =str6;
    document.getElementById('span7').textContent =str7;
    
  }