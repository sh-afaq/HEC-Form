function readVariable() {
    var str1 = document.getElementById("organization").value;          
    var str2 = document.getElementById("sector").value;
    var str3 = document.getElementById("job-type").value;
    var str4 = document.getElementById("job-title").value;
    var str5 = document.getElementById("field").value;
    var str6 = document.getElementById("job-date").value;
    
    
    
    //printing values
  
    document.getElementById('span1').textContent = str1;
    document.getElementById('span2').textContent = str2;
    document.getElementById('span3').textContent =str3;
    document.getElementById('span4').textContent = str4;
    document.getElementById('span5').textContent =str5;
    document.getElementById('span6').textContent =str6;
    
    
  }