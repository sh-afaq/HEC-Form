function readVariable() {
    var str1 = document.getElementById("year").value;          
    var str2 = document.getElementById("qualification").value;
    var str3 = document.getElementById("program").value;
    var str4 = document.getElementById("Discipline").value;
    var str5 = document.getElementById("uni").value;
    
    
    
    //printing values
    
    document.getElementById('span1').textContent = str1;
    document.getElementById('span2').textContent = str2;
    document.getElementById('span3').textContent =str3;
    document.getElementById('span4').textContent = str4;
    document.getElementById('span5').textContent =str5;
    
    
  }