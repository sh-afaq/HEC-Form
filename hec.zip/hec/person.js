function testVariable() {
  var strText1 = document.getElementById("title").value;          
  var strText2 = document.getElementById("fname").value;
  var strText3 = document.getElementById("m-name").value;
  var strText4 = document.getElementById("l-name").value;
  var strText5 = document.getElementById("full-name").value;
  var strText6 = document.querySelector('input[name="marital"]:checked').value;
  var strText7 = document.querySelector('input[name="gender"]:checked').value;
  var strText8 = document.getElementById("birthday").value;
  var strText9 = document.getElementById("country").value;
  var strText10 = document.getElementById("religion").value;
  var strText11 = document.getElementById("domicile").value;
  var strText12 = document.getElementById("Location").value;
  var strText13 = document.getElementById("domicile-district").value;
  var strText14 = document.getElementById("coun-try").value;
  var strText15 = document.getElementById("type").value;
  var strText16 = document.getElementById("idnumber").value;
  var strText17 = document.getElementById("father-name").value;
  var strText18 = document.getElementById("cnic").value;
  var strText19 = document.querySelector('input[name="status"]:checked').value;
  var strText20 = document.getElementById("Occupation").value;
  //printing values

  document.getElementById('spanResult1').textContent = strText1;
  document.getElementById('spanResult2').textContent = strText2;
  document.getElementById('spanResult3').textContent =strText3;
  document.getElementById('spanResult4').textContent = strText4;
  document.getElementById('spanResult5').textContent =strText5;
  document.getElementById('spanResult6').textContent =strText6;
  document.getElementById('spanResult7').textContent =strText7;
  document.getElementById('spanResult8').textContent =strText8;
  document.getElementById('spanResult9').textContent = strText9;
  document.getElementById('spanResult10').textContent = strText10;
  document.getElementById('spanResult11').textContent =strText11;
  document.getElementById('spanResult12').textContent = strText12;
  document.getElementById('spanResult13').textContent =strText13;
  document.getElementById('spanResult14').textContent =strText14;
  document.getElementById('spanResult15').textContent =strText15;
  document.getElementById('spanResult16').textContent =strText16;
  document.getElementById('spanResult17').textContent =strText17;
  document.getElementById('spanResult18').textContent =strText18;
  document.getElementById('spanResult19').textContent =strText19;
  document.getElementById('spanResult20').textContent =strText20;
   
}